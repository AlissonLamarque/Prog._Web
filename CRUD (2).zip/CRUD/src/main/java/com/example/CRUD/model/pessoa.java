package com.example.CRUD.model;


import jakarta.persistence.*;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@Setter
@Entity
public class pessoa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column (nullable = false)
    @NonNull //DIZ QUE É OBRIGATÓRIO PARA O CONSTRUTOR
    private String nome;
    @Column (nullable = false, unique = true, length = 100)
    @NonNull
    private String email;
    @Column (nullable = false)
    @NonNull 
    private String telefone;
}
