package com.example.CRUD.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller // ISSO SIGNIFICA QUE ESSA CLASSE AGORA É UMA CONTROLLER
public class WebController {
    @GetMapping ("/cadastro")
    public String redirecionarCadastro(){
        return "cadastro";
    }

    @GetMapping ("/alterar")
    public String redirecionarAlterar(){
        return "alterar";
    }

    @GetMapping ("/listar")
    public String redirecionarListar(){
        return "listar";
    }
}
